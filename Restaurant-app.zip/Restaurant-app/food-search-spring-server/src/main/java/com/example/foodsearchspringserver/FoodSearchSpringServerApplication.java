package com.example.foodsearchspringserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodSearchSpringServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodSearchSpringServerApplication.class, args);
	}

}

package com.example.foodsearchspringserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodSearchSpringServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
